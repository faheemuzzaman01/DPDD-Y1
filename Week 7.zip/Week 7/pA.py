def perimeter(length, width):
    result = (length + width) * 2
    return result

def area(length, width):
    result = length * width
    print(f"The area of the quadrilateral is {round(result, 2)}.")

while True:
    l = input("Please enter the length of the quadrilateral: ")
    try:
        l = int(l)
        break
    except:
        try:
            l = float(l)
            break
        except:
            print("ERROR: The length must be a number.")

while True:
    w = input("Please enter the width of the quadrilateral: ")
    try:
        w = int(w)
        break
    except:
        try:
            w = float(w)
            break
        except:
            print("ERROR: The width must be a number.")

print(f"The perimeter of the quadrilateral is {round(perimeter(l, w), 2)}")

area(l, w)