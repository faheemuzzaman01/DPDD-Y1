def addInterest(amount, interestRate):
    interest = amount * (interestRate / 100)
    result = interest + amount
    return result

balance = float(input("How much money is in your account? > £"))
rate = float(input("What is your interest rate? > "))

print(f"Your new balance is: £{round(addInterest(balance, rate), 2):.2f}")