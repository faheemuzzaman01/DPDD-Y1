# def input_data():
#     name = input("Enter your name: ")
#     return name
# def process_data(name):
#     return name.upper()
# def output_data(name):
#     print("Hello, " + name + "!")
# name = input_data()
# name = process_data(name)
# output_data(name)

def subtraction(number, number2):
    return number - number2

def multiplication(number, number2):
    return number * number2

while True:
    num1 = input("Enter a number: ")
    try:
        num1 = int(num1)
        break
    except:
        try:
            num1 = float(num1)
            break
        except:
            print("ERROR: That is not a number.")

while True:
    num2 = input("Enter another number: ")
    try:
        num2 = int(num2)
        break
    except:
        try:
            num2 = float(num2)
            break
        except:
            print("ERROR: That is not a number.")

print(f"{num1} - {num2} = {round(subtraction(num1, num2), 2)}")

while True:
    num1 = input("Enter a number: ")
    try:
        num1 = int(num1)
        break
    except:
        try:
            num1 = float(num1)
            break
        except:
            print("ERROR: That is not a number.")

while True:
    num2 = input("Enter another number: ")
    try:
        num2 = int(num2)
        break
    except:
        try:
            num2 = float(num2)
            break
        except:
            print("ERROR: That is not a number.")

print(f"{num1} * {num2} = {round(multiplication(num1, num2), 2)}")