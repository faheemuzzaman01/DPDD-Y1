import math

def distance(x1, x2, y1, y2):
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

coordX1 = float(input("Give the first x co-ordinate: "))
coordY1 = float(input("Give the first y co-ordinate: "))
coordX2 = float(input("Give the second x co-ordinate: "))
coordY2 = float(input("Give the second y co-ordinate: "))

print(f"Distance between ({coordX1}, {coordY1}) and ({coordX2}, {coordY2}): {distance(coordX1, coordX2, coordY1, coordY2)}")