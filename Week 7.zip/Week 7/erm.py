def factorial(number):
    if number == 0:
        return 1
    else:
        return number * factorial(number - 1)

choice = input("Enter a positive integer: ")

while True:
    try:
        choice = int(choice)
        break
    except:
        print("ERROR: That is not an integer.")
        choice = input("Enter a positive integer: ")
        continue

while True:
    if choice >= 0:
        print(f"The factorial of {choice} is {factorial(choice)}.")
        break
    else:
        print("ERROR: That is not a positive integer.")
        choice = input("Enter a positive integer: ")
        while True:
            try:
                choice = int(choice)
                break
            except:
                print("ERROR: That is not an integer.")
                choice = input("Enter a positive integer: ")
                continue
        continue