import os
user = os.getlogin()
print(user)