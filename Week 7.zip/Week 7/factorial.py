def factorial(number):
    if number == 0:
        return 1
    else:
        return number * factorial(number - 1)
        
choice = int(input("Please enter an integer number: "))
print(f"Factorial of {choice}: {factorial(choice)}")