import time
from sys import stdout as std

def printy(txt, delay = 0.02, delay1 = 0.25, delay2 = 0.5, end = "\n"):
    for char in txt:
        std.write(char)
        if char in ".?!":
            time.sleep(delay2)
        elif char in ":,":
            time.sleep(delay1)
        else:
            time.sleep(delay)
    std.write(end)
    std.flush()

def happy():
    printy("Happy birthday to you!")

def birthdaySong(person):
    happy()
    happy()
    printy(f"Happy birthday, dear {person}...")
    happy()

def square(x):
    return x ** 2

printy("Who is the birthday person?")
name = input("> ")

birthdaySong(name)

printy("How old are you today?")
age = int(input("> "))

printy(f"Your age squared is {square(age)}!")