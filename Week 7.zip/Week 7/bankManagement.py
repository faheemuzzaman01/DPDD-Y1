import glob, os

def addInterest(amount, rate):
    interestToAdd = amount * (rate / 100)
    amount += interestToAdd
    return amount

print("Welcome to the Bank Management Console (BMC).")

print("\nAccounts available:")
for file in glob.glob("ACCOUNT\\*"):
    print(file)
while True:
    choice = input("\nWhich account would you like to view (TYPE ONLY THE ACCOUNT NUMBER)? > ")
    try:
        with open(f"ACCOUNT\\{choice}") as file:
            content = file.readlines()
            balance = content[0]
            interest = content[1]
        balance = round(float(balance), 2)
        interest = float(interest)
        print(f"Current Balance: £{balance:.2f}")
        print(f"Interest Rate: {interest}%")
        balance = round(addInterest(balance, interest), 2)
        print(f"New Balance: £{balance:.2f}")
        with open(f"ACCOUNT\\{choice}", "w") as file:
            file.write(f"{balance:.2f}\n{interest}")
        os.system("pause")
        break
    except FileNotFoundError:
        print("ERROR: Bank Account not found.")
        continue