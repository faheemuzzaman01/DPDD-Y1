def sumDiff(x, y):
    sum = x + y
    diff = x - y
    return sum, diff

num1, num2 = int(input("Please enter 2 numbers: "))
sumResult, diffResult = sumDiff(num1, num2)
print(f"The sum is {sumResult} and the difference is {diffResult}")